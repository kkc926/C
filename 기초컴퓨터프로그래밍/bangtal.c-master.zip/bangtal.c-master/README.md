# bangtal examples
[bangtal library](https://bangtal.bosornd.com)를 사용해서 게임을 만드는 예제 프로젝트입니다.

## Example1
![Example1](https://github.com/bosornd/bangtal.c/blob/master/Example1/Example1.PNG)
방탈출 게임을 만드는 기본 예제입니다.

## Example2
![Example2](https://github.com/bosornd/bangtal.c/blob/master/Example2/Example2.PNG)
키보드를 사용해서 공의 위치를 조작하는 예제입니다.

## 산타레이스
![산타레이스](https://github.com/bosornd/bangtal.c/blob/master/SantaRace/SantaRace.PNG)
마우스를 클릭하여 주어진 시간동안에 산타를 이동시켜야 합니다.

## 틀린그림찾기
![SpotDifference](https://github.com/bosornd/bangtal.c/blob/master/SpotDifference/SpotDifference.PNG)
좌/우 그림에서 틀린 위치를 찾는 게임입니다.
